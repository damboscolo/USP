package view;

import Utils.Config;
import controller.DBFuncionalidades;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.io.File;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFileChooser;
import java.awt.Image;
import java.io.IOException;
import java.sql.Date;
import javax.imageio.ImageIO;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import model.Coluna;
import model.Linha;
import model.Resumo;
import model.Tabela;

public class jTabelas extends javax.swing.JFrame {

    DBFuncionalidades db;
    Tabela tabela;
    ArrayList<Coluna> arrayColunas;
    ArrayList<Linha> arrayLinhas;
    int numeroColunas;
    int numeroLinhas;
    int linhaSelecionada;

    DefaultTableModel defaultModel; //Modelo da Tabela  
    ResultSet rs;
    File fileSelecionado;
    JButton btnSalvar;
    JButton btnLimpar;
    JButton btnImage;

    public jTabelas() {
        initComponents();
        db = DBFuncionalidades.getInstance();
        ArrayList<String> arNomesTabelas = db.getNomesdasTabelas();

        //Preenche combobox com os nomes das tabelas
        for (String nomeTabela : arNomesTabelas) {
            jcbNomesTabelas.addItem(nomeTabela);
        }
        label2.setText(db.getNome()); //nome do usuário
    }

    public void atualizaMsg(String msg) {
        jtxtMsg.setText(msg);
    }

    public void getDadosDoBanco() throws SQLException, ParseException {
        // Pega dados do banco de dados
        String tabelaSelecionada = jcbNomesTabelas.getSelectedItem().toString();
        tabela = db.criaTabelaComColunas(tabelaSelecionada);
    }

    public void constroiTabela() throws SQLException {
        defaultModel = (DefaultTableModel) jTable.getModel();
        defaultModel.setRowCount(0); // Deleta valores antigos da tabela

        fileSelecionado = new File("");

        //Seta colunas e linhas
        numeroColunas = 0;
        numeroLinhas = 0;
        arrayColunas = tabela.getColunas();
        arrayLinhas = tabela.getLinhas();
        numeroColunas = arrayColunas.size();
        numeroLinhas = arrayLinhas.size();

        defaultModel.setColumnIdentifiers(tabela.getColunasNomes().toArray()); //Set nomes das colunas

        // Popula a tabela com as linhas 
        for (Linha linha : arrayLinhas) {
            defaultModel.addRow(linha.getValores().toArray());
        }
        jTable.setModel(defaultModel);
    }

    public void constroiTabelaResumo(ArrayList<Resumo> arrayResumo) throws SQLException {
        defaultModel = (DefaultTableModel) jtbGrupo.getModel();
        defaultModel.setRowCount(0); // Deleta valores antigos da tabela

        // Popula a tabela com as linhas 
        int i = 1;
        for (Resumo resumo : arrayResumo) {
            defaultModel.addRow(resumo.getTodosValoresString(i).toArray());
            i++;
        }
        jtbGrupo.setModel(defaultModel);
    }

    public void constroiLabelsETexts() throws SQLException {
        jpnOperacoes.removeAll(); // Limpa o Panel
        GridLayout gLayout = new GridLayout();
        gLayout.setColumns(2);
        gLayout.setRows(numeroColunas + 1);

        jpnOperacoes.setLayout(gLayout); //Seta o layout

        // Colunas da tabela
        arrayColunas = tabela.getColunas();

        for (Coluna col : arrayColunas) {
            // LABEL do nome da coluna
            jpnOperacoes.add(new JLabel(col.getsNome()));

            // COMBOBOX se for FK ou CHECK
            if ((col.getsConstraint() != null) && (col.getsConstraint().equals(Config.kFK) || col.getsConstraint().equals(Config.kCHECK))) {
                JComboBox combobox = new JComboBox();
                for (String valorCheck : col.getArrayConstraints()) {
                    combobox.addItem(valorCheck);
                }
                jpnOperacoes.add(combobox);
                //BLOB coloca um botao para selecionar imagem
            } else if (col.getsTipo().equals("BLOB")) {
                btnImage = new JButton("Clique para escolher imagem");
                btnImage.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        JFileChooser fc = new JFileChooser();
                        int returnValue = fc.showOpenDialog(null);
                        if (returnValue == JFileChooser.APPROVE_OPTION) {
                            File file = fc.getSelectedFile();
                            System.out.println(file.getPath());
                            try {
                                fileSelecionado = file;
                                Image img = ImageIO.read(file);
                                img = img.getScaledInstance(100, 70, java.awt.Image.SCALE_SMOOTH);
                                btnImage.setIcon(new ImageIcon(img));
                                btnImage.setText("");
                            } catch (Exception ex) {
                                Logger.getLogger(jTabelas.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }

                    }
                });
                jpnOperacoes.add(btnImage);
            } // TEXTFIELD se for campo digitado
            else {
                jpnOperacoes.add(new JTextField(""));
            }
        }

        //---------------------------------- DOIS BOTOES ABAIXO --------------------------------------
        // Botao Limpar
        btnLimpar = new JButton("Limpar");
        btnLimpar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                limpaCampos();
            }
        });

        // Botao Salvar
        btnSalvar = new JButton("Inserir");
        btnSalvar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    //INSERIR e ALTERAR
                    if (rdBtnInserir.isSelected() || rdBtnAlterar.isSelected()) {
                        inserirAlterar();
                        constroiTabela();//Se inseriu ou alterou, atualiza tabela
                    } //EXCLUIR
                    else if (rdBtnExcluir.isSelected()) {
                        excluir();
                    }
                } catch (Exception ex) {
                    Logger.getLogger(jTabelas.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
        jpnOperacoes.add(btnLimpar);
        jpnOperacoes.add(btnSalvar);
        setBotoes();
    }

    // ------------------------------- OPERACOES --------------------------------------------------------
    public void limpaCampos() {
        JTextField jtf;
        for (int i = 0; i < jpnOperacoes.getComponentCount() - 2; i++) { // -2 por causa dos dois ultimos botoes
            if (i % 2 == 1) { //Numero par nao é label
                if (jpnOperacoes.getComponent(i) instanceof JTextField) { //se é uma textField, limpa
                    jtf = (JTextField) jpnOperacoes.getComponent(i);
                    jtf.setText("");
                }
            }
        }
    }

    public void visualizar() {
        try {
            JTextField jtf;
            JComboBox cb;
            int countValor = 0;

            Linha linha = arrayLinhas.get(linhaSelecionada);

            //Se for a tabela JOGO mostra o resumo do jogo na txtMsg
            if (tabela.getsNome().equals("JOGO")) {
                resumoJogo();
            }

            //Pega a linhaSelecionada
            for (int i = 0; i < jpnOperacoes.getComponentCount() - 2; i++) { //-2 por causa dos dois ultimos botoes
                //Se numero impar entao nao é label
                if (i % 2 != 0) {
                    //TEXTFIELD
                    if (jpnOperacoes.getComponent(i) instanceof JTextField) {
                        jtf = (JTextField) jpnOperacoes.getComponent(i);
                        jtf.setText(linha.getValores().get(countValor));
                    } //COMBOBOX
                    else if (jpnOperacoes.getComponent(i) instanceof JComboBox) {
                        cb = (JComboBox) jpnOperacoes.getComponent(i);
                        cb.setSelectedItem(linha.getValores().get(countValor).trim());
                    } //BOTAO BLOB
                    else {
                        ImageIcon img = db.getNacaoBandeira(linha.getValores().get(0));
                        if (img == null) {
                            btnImage.setText("Clique para escolher imagem");
                        } else {
                            btnImage.setText("");
                        }
                        btnImage.setIcon(img);
                    }
                    countValor++; // Soma para o proximo valor a ser inserido
                }
            }
        } catch (IOException | SQLException ex) {
            Logger.getLogger(jTabelas.class.getName()).log(Level.SEVERE, null, ex);
            jtxtMsg.setText(ex.getMessage());
        }
    }

    public void resumoJogo() {
        //Passa o idJogo para receber o Resumo do Jogo
        try {
            int idJogo = Integer.parseInt(arrayLinhas.get(linhaSelecionada).getValores().get(0));
            String str = db.getResumoJogo(idJogo);
            jtxtMsg.setText(str);
        } catch (NumberFormatException | SQLException ex) {
            Logger.getLogger(jTabelas.class.getName()).log(Level.SEVERE, null, ex);
            jtxtMsg.setText("Dados insuficientes para montar o resumo do jogo.");
        }
    }

    public void inserirAlterar() throws Exception {
        try {
            ArrayList<String> arrayValores = new ArrayList<>();

            StringBuilder strValor = new StringBuilder();
            JTextField jtf;
            JComboBox combobox;
            int i = 0;

            for (i = 0; i < jpnOperacoes.getComponentCount() - 2; i++) { // -2 por causa dos dois botoes
                //Se numero impar entao nao é label
                if (i % 2 != 0) {
                    strValor.setLength(0); //Zera stringBuilder para proximo valor
                    System.out.print(arrayColunas.get(i / 2).getsNome() + " = ");

                    // COMBOBOX
                    if (jpnOperacoes.getComponent(i) instanceof JComboBox) {
                        combobox = (JComboBox) jpnOperacoes.getComponent(i);
                        strValor.append((String) combobox.getSelectedItem());
                        arrayValores.add(strValor.toString());
                    } else if (jpnOperacoes.getComponent(i) instanceof JTextField) { // TEXTFIELD
                        jtf = (JTextField) jpnOperacoes.getComponent(i);//textField
                        strValor.append(jtf.getText());
                        arrayValores.add(strValor.toString());
                    }
                    System.out.print(strValor.toString() + "\n\n");
                }
            }
            //INSERIR
            if (rdBtnInserir.isSelected()) {
                //TABELA NACAO insere BLOB
                if (tabela.getsNome().equals("NACAO")) {
                    db.inserirNacaoBandeira(arrayValores.get(0), fileSelecionado);
                } else {
                    db.inserirDados(tabela, arrayValores);
                }
                numeroLinhas++; //uma linha a mais
                jtxtMsg.setText("Dados inseridos com sucesso na tabela " + tabela.getsNome());
            } //ALTERAR
            else {
                //TABELA NACAO altera BLOB
                if (tabela.getsNome().equals("NACAO")) {
                    db.alteraNacaoBandeira(arrayValores.get(0), fileSelecionado);
                } else {
                    db.alterarDados(tabela, arrayValores, linhaSelecionada);
                }
                jtxtMsg.setText("Dados alterados com sucesso na tabela " + tabela.getsNome());
            }

        } catch (SQLException ex) {
            Logger.getLogger(jTabelas.class.getName()).log(Level.SEVERE, null, ex);
            jtxtMsg.setText(ex.getMessage());
        }
    }

    public void excluir() throws Exception {
        try {
            db.excluirLinha(tabela, linhaSelecionada);

            //Vai para a linha anterior
            linhaSelecionada = (linhaSelecionada == 0) ? 0 : --linhaSelecionada;
            numeroLinhas--; //Uma linha a menos
            visualizar();
            verificaPrevNext();
            jtxtMsg.setText("Dados excluídos com sucesso da tabela " + tabela.getsNome());
        } catch (SQLException ex) {
            Logger.getLogger(jTabelas.class.getName()).log(Level.SEVERE, null, ex);
            jtxtMsg.setText(ex.getMessage());
        }
    }

    // ---------------------------------- METODOS AUXILIARES ----------------------------------------
    public void setBotoesEnabled() {
        rdBtnInserir.setEnabled(true);
        rdBtnVisualizar.setEnabled(true);
        rdBtnAlterar.setEnabled(true);
        rdBtnExcluir.setEnabled(true);

        // PREV e NEXT ficam disabled quando a operacao de inserçao estiver selecionada
        if (rdBtnInserir.isSelected()) {
            btnPrev.setEnabled(false);
            btnNext.setEnabled(false);
        } else {
            verificaPrevNext();
        }
    }

    public void setBotoes() {
        //VISUALIZAR
        if (rdBtnVisualizar.isSelected()) {
            btnLimpar.setVisible(false);
            btnSalvar.setVisible(false);
        } //INSERIR
        else if (rdBtnInserir.isSelected()) {
            btnLimpar.setVisible(true);
            btnSalvar.setVisible(true);
            btnSalvar.setText("Inserir");
        } //ALTERAR
        else if (rdBtnAlterar.isSelected()) {
            btnLimpar.setVisible(true);
            btnSalvar.setVisible(true);
            btnSalvar.setText("Editar");
        } //Excluir
        else if (rdBtnExcluir.isSelected()) {
            btnLimpar.setVisible(false);
            btnSalvar.setVisible(true);
            btnSalvar.setText("Excluir");
        }
        verificaPrevNext();
    }

    // Botoes PREV e NEXT
    private void verificaPrevNext() {
        //Em INSERIR os dois botoes ficam disabled
        if (!rdBtnInserir.isSelected()) {
            if (linhaSelecionada == 0) {
                btnPrev.setEnabled(false);
                btnNext.setEnabled(true);
            } else if (linhaSelecionada == numeroLinhas - 1) {
                btnPrev.setEnabled(true);
                btnNext.setEnabled(false);
            } else {
                btnPrev.setEnabled(true);
                btnNext.setEnabled(true);
            }
        } else {
            btnPrev.setEnabled(false);
            btnNext.setEnabled(false);
        }
    }

    //TextField ou ComboBox do valor PK pode ser alterado somente na operaçao INSERIR
    public void setPKEnabled() {
        Boolean bol = rdBtnInserir.isSelected();//verifica se INSERIR está selecionado

        //TEXTFIELD            
        if (jpnOperacoes.getComponent(1) instanceof JTextField) {
            JTextField txt = (JTextField) jpnOperacoes.getComponent(1);
            txt.setEnabled(bol);
        } //COMBOBOX
        else {
            JComboBox cb = (JComboBox) jpnOperacoes.getComponent(1);
            cb.setEnabled(bol);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        rdBtnGroup = new javax.swing.ButtonGroup();
        jcbNomesTabelas = new javax.swing.JComboBox();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jtxtMsg = new javax.swing.JTextArea();
        jTabResumo = new javax.swing.JTabbedPane();
        jPanelTabela = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable = new javax.swing.JTable();
        jpnOperacoes = new javax.swing.JPanel();
        jpnResumo = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        jlistGrupos = new javax.swing.JList();
        jScrollPane5 = new javax.swing.JScrollPane();
        jtbGrupo = new javax.swing.JTable();
        jScrollPane6 = new javax.swing.JScrollPane();
        jlistGrupos2 = new javax.swing.JList();
        jbtnDesconectar = new javax.swing.JButton();
        label2 = new java.awt.Label();
        rdBtnVisualizar = new javax.swing.JRadioButton();
        rdBtnAlterar = new javax.swing.JRadioButton();
        rdBtnExcluir = new javax.swing.JRadioButton();
        jLabel2 = new javax.swing.JLabel();
        btnPrev = new javax.swing.JButton();
        btnNext = new javax.swing.JButton();
        rdBtnInserir = new javax.swing.JRadioButton();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(51, 51, 255));

        jcbNomesTabelas.setFont(new java.awt.Font("Calibri", 0, 18)); // NOI18N
        jcbNomesTabelas.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Selecione" }));
        jcbNomesTabelas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jcbNomesTabelasActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Calibri", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 153));
        jLabel1.setText("Tabela:");

        jtxtMsg.setEditable(false);
        jtxtMsg.setColumns(5);
        jtxtMsg.setFont(new java.awt.Font("Calibri", 0, 13)); // NOI18N
        jtxtMsg.setRows(6);
        jtxtMsg.setWrapStyleWord(true);
        jScrollPane1.setViewportView(jtxtMsg);

        jTabResumo.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        jTable.setFont(new java.awt.Font("Calibri", 0, 11)); // NOI18N
        jTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTable.setEnabled(false);
        jScrollPane2.setViewportView(jTable);

        javax.swing.GroupLayout jPanelTabelaLayout = new javax.swing.GroupLayout(jPanelTabela);
        jPanelTabela.setLayout(jPanelTabelaLayout);
        jPanelTabelaLayout.setHorizontalGroup(
            jPanelTabelaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 975, Short.MAX_VALUE)
        );
        jPanelTabelaLayout.setVerticalGroup(
            jPanelTabelaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 382, Short.MAX_VALUE)
        );

        jTabResumo.addTab("Tabela", jPanelTabela);

        javax.swing.GroupLayout jpnOperacoesLayout = new javax.swing.GroupLayout(jpnOperacoes);
        jpnOperacoes.setLayout(jpnOperacoesLayout);
        jpnOperacoesLayout.setHorizontalGroup(
            jpnOperacoesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 975, Short.MAX_VALUE)
        );
        jpnOperacoesLayout.setVerticalGroup(
            jpnOperacoesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 382, Short.MAX_VALUE)
        );

        jTabResumo.addTab("Operações", jpnOperacoes);

        jLabel3.setFont(new java.awt.Font("Calibri", 0, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 153));
        jLabel3.setText("Grupo:");

        jlistGrupos.setFont(new java.awt.Font("Calibri", 0, 20)); // NOI18N
        jlistGrupos.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "A", "B", "C", "D" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        jlistGrupos.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jlistGrupos.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jlistGrupos.setSelectionBackground(new java.awt.Color(255, 255, 255));
        jlistGrupos.setSelectionForeground(new java.awt.Color(0, 0, 0));
        jlistGrupos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jlistGruposMousePressed(evt);
            }
        });
        jScrollPane4.setViewportView(jlistGrupos);

        jtbGrupo.setFont(new java.awt.Font("Calibri", 0, 13)); // NOI18N
        jtbGrupo.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Colocação", "Seleção", "Num Jogos", "Pontos", "Gols marcados", "Gols sofridos", "Saldo", "Vitórias", "Derrotas", "Empates", "Média Gols", "Variância Gols", "% Aprovação"
            }
        ));
        jtbGrupo.setEnabled(false);
        jtbGrupo.setUpdateSelectionOnSort(false);
        jScrollPane5.setViewportView(jtbGrupo);
        if (jtbGrupo.getColumnModel().getColumnCount() > 0) {
            jtbGrupo.getColumnModel().getColumn(12).setResizable(false);
        }

        jlistGrupos2.setFont(new java.awt.Font("Calibri", 0, 20)); // NOI18N
        jlistGrupos2.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "E", "F", "G", "H" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        jlistGrupos2.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jlistGrupos2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jlistGrupos2.setSelectionBackground(new java.awt.Color(255, 255, 255));
        jlistGrupos2.setSelectionForeground(new java.awt.Color(0, 0, 0));
        jlistGrupos2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jlistGrupos2MousePressed(evt);
            }
        });
        jScrollPane6.setViewportView(jlistGrupos2);

        javax.swing.GroupLayout jpnResumoLayout = new javax.swing.GroupLayout(jpnResumo);
        jpnResumo.setLayout(jpnResumoLayout);
        jpnResumoLayout.setHorizontalGroup(
            jpnResumoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnResumoLayout.createSequentialGroup()
                .addGap(227, 227, 227)
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(444, Short.MAX_VALUE))
            .addGroup(jpnResumoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jpnResumoLayout.createSequentialGroup()
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 965, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        jpnResumoLayout.setVerticalGroup(
            jpnResumoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnResumoLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jpnResumoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel3)
                    .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 129, Short.MAX_VALUE)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addContainerGap(238, Short.MAX_VALUE))
            .addGroup(jpnResumoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpnResumoLayout.createSequentialGroup()
                    .addGap(0, 160, Short.MAX_VALUE)
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        jTabResumo.addTab("Resumo", jpnResumo);

        jbtnDesconectar.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jbtnDesconectar.setText("Desconectar");
        jbtnDesconectar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnDesconectarActionPerformed(evt);
            }
        });

        label2.setFont(new java.awt.Font("Calibri", 0, 18)); // NOI18N

        rdBtnGroup.add(rdBtnVisualizar);
        rdBtnVisualizar.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        rdBtnVisualizar.setText("Visualizar");
        rdBtnVisualizar.setEnabled(false);
        rdBtnVisualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdBtnInserirActionPerformed(evt);
            }
        });

        rdBtnGroup.add(rdBtnAlterar);
        rdBtnAlterar.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        rdBtnAlterar.setText("Alterar");
        rdBtnAlterar.setEnabled(false);
        rdBtnAlterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdBtnInserirActionPerformed(evt);
            }
        });

        rdBtnGroup.add(rdBtnExcluir);
        rdBtnExcluir.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        rdBtnExcluir.setText("Excluir");
        rdBtnExcluir.setEnabled(false);
        rdBtnExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdBtnInserirActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Calibri", 0, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 153));
        jLabel2.setText("Usuário:");

        btnPrev.setFont(new java.awt.Font("SimSun", 1, 36)); // NOI18N
        btnPrev.setText("<");
        btnPrev.setEnabled(false);
        btnPrev.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPrevActionPerformed(evt);
            }
        });

        btnNext.setFont(new java.awt.Font("SimSun", 1, 36)); // NOI18N
        btnNext.setText(">");
        btnNext.setEnabled(false);
        btnNext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNextActionPerformed(evt);
            }
        });

        rdBtnGroup.add(rdBtnInserir);
        rdBtnInserir.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        rdBtnInserir.setSelected(true);
        rdBtnInserir.setText("Inserir");
        rdBtnInserir.setEnabled(false);
        rdBtnInserir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdBtnInserirActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Calibri", 0, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 153));
        jLabel4.setText("Opção:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTabResumo)
                    .addComponent(jScrollPane1)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jcbNomesTabelas, javax.swing.GroupLayout.PREFERRED_SIZE, 231, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(157, 157, 157))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(rdBtnExcluir)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(rdBtnAlterar)
                                            .addComponent(rdBtnVisualizar))
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(rdBtnInserir)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel2)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(label2, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(34, 34, 34)
                                .addComponent(jbtnDesconectar))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnPrev)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnNext)))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jbtnDesconectar, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnPrev, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jcbNomesTabelas, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(label2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabel4)
                                        .addComponent(jLabel2)))
                                .addGap(9, 9, 9))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(rdBtnInserir)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                        .addComponent(rdBtnVisualizar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(rdBtnAlterar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(rdBtnExcluir)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTabResumo, javax.swing.GroupLayout.PREFERRED_SIZE, 418, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jbtnDesconectarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnDesconectarActionPerformed
        DBFuncionalidades db = DBFuncionalidades.getInstance();
        try {
            db.getConnection().close();
        } catch (SQLException ex) {
            Logger.getLogger(jTabelas.class.getName()).log(Level.SEVERE, null, ex);
            jtxtMsg.setText("Não foi possível desconectar.");
        }
        this.setVisible(false);
        Login l = new Login();
        l.setVisible(true);
        jtxtMsg.setText("Desconectado.");
    }//GEN-LAST:event_jbtnDesconectarActionPerformed

    // COMBOBOX nomes das tabelas
    private void jcbNomesTabelasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jcbNomesTabelasActionPerformed
        try {
            if (!jcbNomesTabelas.getSelectedItem().equals("Selecione")) {
                linhaSelecionada = 0;
                getDadosDoBanco();
                constroiTabela();
                constroiLabelsETexts();
                setBotoesEnabled();
            }
        } catch (SQLException ex) {
            Logger.getLogger(jTabelas.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParseException ex) {
            Logger.getLogger(jTabelas.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jcbNomesTabelasActionPerformed

    private void rdBtnInserirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdBtnInserirActionPerformed
        setBotoes();
        visualizar();

        if (rdBtnInserir.isSelected()) {
            limpaCampos();
        }
    }//GEN-LAST:event_rdBtnInserirActionPerformed

    // ---------------------------- BOTOES PREV E NEXT ---------------------------------------------------
    private void btnPrevActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPrevActionPerformed
        linhaSelecionada--;
        visualizar();
        verificaPrevNext();
    }//GEN-LAST:event_btnPrevActionPerformed

    private void btnNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextActionPerformed
        linhaSelecionada++;
        visualizar();
        verificaPrevNext();
    }//GEN-LAST:event_btnNextActionPerformed

    // ------------------------------------- LISTA DE GRUPOS ---------------------------
    private void jlistGruposMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlistGruposMousePressed
        try {
            int grupoSelecionado = jlistGrupos.getSelectedIndex() + 1;
            ArrayList<Resumo> arrayResumo = db.resumoGrupos(grupoSelecionado);
            constroiTabelaResumo(arrayResumo);
        } catch (Exception ex) {
            Logger.getLogger(jTabelas.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jlistGruposMousePressed

    //Lista grupos 2
    private void jlistGrupos2MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlistGrupos2MousePressed
        try {
            int grupoSelecionado = jlistGrupos2.getSelectedIndex() + 5;
            ArrayList<Resumo> arrayResumo = db.resumoGrupos(grupoSelecionado);
            constroiTabelaResumo(arrayResumo);
        } catch (SQLException ex) {
            Logger.getLogger(jTabelas.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jlistGrupos2MousePressed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(jTabelas.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(jTabelas.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(jTabelas.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(jTabelas.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new jTabelas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnNext;
    private javax.swing.JButton btnPrev;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanelTabela;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JTabbedPane jTabResumo;
    private javax.swing.JTable jTable;
    private javax.swing.JButton jbtnDesconectar;
    private javax.swing.JComboBox jcbNomesTabelas;
    private javax.swing.JList jlistGrupos;
    private javax.swing.JList jlistGrupos2;
    private javax.swing.JPanel jpnOperacoes;
    private javax.swing.JPanel jpnResumo;
    private javax.swing.JTable jtbGrupo;
    private javax.swing.JTextArea jtxtMsg;
    private java.awt.Label label2;
    private javax.swing.JRadioButton rdBtnAlterar;
    private javax.swing.JRadioButton rdBtnExcluir;
    private javax.swing.ButtonGroup rdBtnGroup;
    private javax.swing.JRadioButton rdBtnInserir;
    private javax.swing.JRadioButton rdBtnVisualizar;
    // End of variables declaration//GEN-END:variables
}
