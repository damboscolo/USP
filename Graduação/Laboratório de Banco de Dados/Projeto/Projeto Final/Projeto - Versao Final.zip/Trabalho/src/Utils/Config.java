package Utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;

public class Config {

    // Valores das Constraints das colunas SQL
    // R(FK) / C(CHECK) / U(Unique Key)
    public static final String kFK = "R";
    public static final String kCHECK = "C";
    public static final String kUniq = "U";

    public static String formatarData(String date) throws ParseException {
        SimpleDateFormat dt = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        java.util.Date newdate = dt.parse(date);
        SimpleDateFormat dt1 = new SimpleDateFormat("dd/MM/yy");
        String str = (String) dt1.format(newdate);
        return str;
    }
}
