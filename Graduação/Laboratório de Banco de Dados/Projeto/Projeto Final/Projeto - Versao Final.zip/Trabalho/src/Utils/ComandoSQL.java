package Utils;

public class ComandoSQL {

    //infoBasicas
    public static final String GET_NOME_TABELAS  = "begin infoBasicas.getNomeTabela  (?);end;";
    public static final String GET_NOMES_COLUNAS = "begin infoBasicas.getNomesColunas(?,?);end;";
    public static final String GET_PK            = "begin infoBasicas.getPrimaryKey  (?,?);end;";
    public static final String GET_FK            = "begin infoBasicas.getForeignKey  (?,?);end;";
    public static final String GET_DADOS_TABELA  = "begin infoBasicas.getDadosTabela (?,?);end;";
    public static final String GET_VALORES_CHECK = "begin infoBasicas.getConstraints (?,?);end;";
    public static final String GET_VALORES_FK    = "begin infoBasicas.getPossiveisValoresFK(?,?,?);end;";

    //operacoesSQL 
    public static final String INSERT_TABLE = "begin operacoesSQL.insertTabela(?,?,?);end;";
    public static final String SELECT_TABLE = "begin operacoesSQL.selectTabela(?,?,?);end;";
    public static final String UPDATE_TABLE = "begin operacoesSQL.updateTabela(?,?,?,?,?);end;";
    public static final String DELETE_TABLE = "begin operacoesSQL.deleteTabela(?,?,?);end;";

    //tabelaResultadoGrupos    
    public static final String GET_DADOSTABELAGRUPO = "begin tabelaResultadoGrupos.dadosTabelaGrupo"
            + "(?,?,?,?,?,?,?,?,?);end;"; //9 atrib

    //nacaoBandeiras
    public static final String INSERT_NACAO       = "begin nacaoBandeiras.insertNacao(?,?);end;";  
    public static final String SET_NACAOBANDEIRAS = "begin nacaoBandeiras.setBandeira(?,?);end;";
    public static final String GET_NACAOBANDEIRAS = "begin nacaoBandeiras.getBandeira(?,?);end;";

    //getResumoJogo
    public static final String GET_RESUMOJOGO = "begin getResumoJogo(?,?);end;";    
      
}
