package controller;

import Utils.ComandoSQL;
import Utils.Config;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JTextArea;
import model.Coluna;
import model.Linha;
import model.Resumo;
import model.Tabela;
import oracle.jdbc.OracleTypes;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;
import view.jTabelas;

public class DBFuncionalidades {

    private static final DBFuncionalidades INSTANCE = new DBFuncionalidades();

    private DBFuncionalidades() {
    }

    public static DBFuncionalidades getInstance() {
        return INSTANCE;
    }

    Connection connection;
    CallableStatement comando;
    Statement stmt;
    ResultSet rs;
    JTextArea jtAreaDeStatus;
    PreparedStatement prepStmt;
    String msg;
    String sql;

    String nome;
    String senha;
    String nomeHost;
    String porta;
    String sid;

    public Connection getConnection() {
        return connection;
    }

    public void setConnection(Connection connection) {
        this.connection = connection;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getNomeHost() {
        return nomeHost;
    }

    public void setNomeHost(String nomeHost) {
        this.nomeHost = nomeHost;
    }

    public String getPorta() {
        return porta;
    }

    public void setPorta(String porta) {
        this.porta = porta;
    }

    public String getSid() {
        return sid;
    }

    public void setSid(String sid) {
        this.sid = sid;
    }

    public String conectar() {
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            connection = DriverManager.getConnection(
                    "jdbc:oracle:thin:@" + this.nomeHost + ":" + this.porta + ":" + this.sid,
                    this.getNome(),
                    this.getSenha());
            System.out.println("Conectado");
            msg = "true";
            return msg;
        } catch (ClassNotFoundException ex) {
            msg = "Erro: verifique o driver do banco de dados.";
        } catch (SQLException ex) {
            msg = "Erro: verifique os dados inseridos.";
        }
        return msg;
    }

    public ArrayList<String> getNomesdasTabelas() {
        try {
            comando = connection.prepareCall(ComandoSQL.GET_NOME_TABELAS);
            comando.registerOutParameter(1, OracleTypes.CURSOR);
            comando.execute();
            rs = (ResultSet) comando.getObject(1); //Pega o cursor

            ArrayList<String> arNomesTabelas = new ArrayList<>();

            while (rs.next()) {
                arNomesTabelas.add(rs.getString("table_name"));
            }
            return arNomesTabelas;
        } catch (SQLException ex) {
            jtAreaDeStatus.setText("Erro na consulta: \"" + sql + "\"");
            return null;
        }
    }

    public Tabela criaTabelaComColunas(String tabelaNome) throws SQLException, ParseException {
        try {
            comando = connection.prepareCall(ComandoSQL.GET_NOMES_COLUNAS);
            comando.registerOutParameter(1, OracleTypes.CURSOR);
            comando.setString(2, tabelaNome.toUpperCase());
            comando.execute();
            rs = (ResultSet) comando.getObject(1); //Pega o cursor

            ArrayList<Coluna> colunas = new ArrayList<>();
            while (rs.next()) {
                Coluna col = new Coluna();
                col.setIdColuna(rs.getInt("COLUMN_ID"));
                col.setsNome(rs.getString("COLUMN_NAME"));
                col.setiTamanho(rs.getInt("DATA_LENGTH"));
                col.setsTipo(rs.getString("DATA_TYPE"));
                col.setNullAble(rs.getString("NULLABLE"));
                colunas.add(col);
            }
            //cria nova tabela
            Tabela tabela = new Tabela(tabelaNome.toUpperCase(), colunas);
            rs.close();

            setPrimaryKeys(tabela); //Seta as PKs
            setForeignKeys(tabela); //Seta as FKs

            System.out.println("Tabela selecionada: " + tabela.getsNome());
            setLinhasNaTabela(tabela);   //Seta as linhas da Tabela ResultSet
            setValoresDosChecks(tabela); //Seta os valores dos CHECKS se houver
            setValoresDaFK(tabela);      //Seta os valores possiveis de FKs na coluna

            return tabela;
        } catch (SQLException ex) {
            jtAreaDeStatus.setText("Erro na consulta: \"" + sql + "\"");
            return null;
        }
    }

    public void setPrimaryKeys(Tabela tabela) throws SQLException {
        try {
            comando = connection.prepareCall(ComandoSQL.GET_PK);
            comando.registerOutParameter(1, OracleTypes.CURSOR);
            comando.setString(2, tabela.getsNome());
            comando.execute();
            rs = (ResultSet) comando.getObject(1); //Pega o cursor

            while (rs.next()) {
                for (Coluna col : tabela.getColunas()) {
                    if (col.getsNome().matches(rs.getString("COLUMN_NAME"))) {
                        col.setIsPrimaryKey(true); // Seta PK
                    }
                }
            }
            rs.close();
        } catch (SQLException ex) {
            jtAreaDeStatus.setText("Erro no comando: " + sql);
            Logger.getLogger(jTabelas.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void setForeignKeys(Tabela tabela) {
        try {
            comando = connection.prepareCall(ComandoSQL.GET_FK);
            comando.registerOutParameter(1, OracleTypes.CURSOR);
            comando.setString(2, tabela.getsNome());
            comando.execute();
            rs = (ResultSet) comando.getObject(1); //Pega o cursor

            while (rs.next()) {
                for (Coluna col : tabela.getColunas()) {
                    if (col.getsNome().matches(rs.getString("COLUMN_NAME"))) {
                        col.setsConstraint(Config.kFK);
                        col.setFkNomeColuna(rs.getString("FK_COLUMN_NAME")); //nomeColuna FK
                        col.setFkNomeTabela(rs.getString("FK_TABLE_NAME")); //nomeTabela FK
                    }
                }
            }
            rs.close();
        } catch (SQLException ex) {
            jtAreaDeStatus.setText("Erro no comando: " + sql);
            Logger.getLogger(jTabelas.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void setLinhasNaTabela(Tabela tabela) throws SQLException, ParseException {
        try {
            comando = connection.prepareCall(ComandoSQL.GET_DADOS_TABELA, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            comando.setString(2, tabela.getsNome());
            comando.registerOutParameter(1, OracleTypes.CURSOR);

            comando.execute();
            rs = (ResultSet) comando.getObject(1);

            Linha novaLinha;
            ArrayList<String> valoresLinha;// Lista de String
            ArrayList<Linha> linhas = new ArrayList<>();//Lista de linhas

            while (rs.next()) {
                valoresLinha = new ArrayList<>();//limpa os valores para proxima linha                
                for (Coluna col : tabela.getColunas()) {
                    if (col.getsTipo().equals("DATE")) {
                        String date = (String) rs.getString(col.getsNome());
                        valoresLinha.add(Config.formatarData(date));
                    } else {
                        valoresLinha.add((String) rs.getString(col.getsNome()));
                    }

                }
                novaLinha = new Linha(valoresLinha);
                linhas.add(novaLinha); //add a novaLinha ao Array de linhas
            }
            tabela.setLinhas(linhas);//Seta as linhas a TABELA
        } catch (SQLException ex) {
            jtAreaDeStatus.setText("Erro no comando: " + sql);
            Logger.getLogger(jTabelas.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void setValoresDosChecks(Tabela tabela) throws SQLException {
        try {
            comando = connection.prepareCall(ComandoSQL.GET_VALORES_CHECK);
            comando.registerOutParameter(1, OracleTypes.CURSOR);
            comando.setString(2, tabela.getsNome());
            comando.execute();

            rs = (ResultSet) comando.getObject(1); // Pega o cursor

            ArrayList<String> arrayValores = new ArrayList<>();
            String[] vetorValor, nomeColuna;
            String condicaoCheck, valor;
            int index = 0;

            while (rs.next()) {
                condicaoCheck = rs.getString("SEARCH_CONDITION");
                if (condicaoCheck.contains(" IN ")) {
                    nomeColuna = condicaoCheck.split(" IN "); // Pega o nome da coluna que tem o CHECK

                    index = condicaoCheck.lastIndexOf(" IN ");
                    valor = condicaoCheck.substring(index + 5, condicaoCheck.length() - 1);
                    valor = valor.replaceAll("'", ""); //Remove todas as aspas simples
                    vetorValor = valor.split(","); //Separa os valores em vetor por virgula

                    for (String vetorValor1 : vetorValor) {
                        arrayValores.add(vetorValor1.trim()); // Tira espacos em branco         
                    }

                    // Adiciona os valores dos CHECKS à coluna correspondente
                    for (Coluna col : tabela.getColunas()) {
                        if (col.getsNome().equals(nomeColuna[0].toUpperCase())) { //Pega o index 0 do vetor nomeColuna
                            col.setsConstraint(Config.kCHECK); //Seta flag de constraint CHECK
                            col.setArrayConstraints(arrayValores); //Seta os valores do CHECK
                        }
                    }
                }
            }
        } catch (SQLException ex) {
            jtAreaDeStatus.setText("Erro no comando: " + sql);
            Logger.getLogger(jTabelas.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void setValoresDaFK(Tabela tabela) throws SQLException {
        try {
            comando = connection.prepareCall(ComandoSQL.GET_VALORES_FK);
            ArrayList<String> arrayValores;

            // Se coluna for FK então salva possiveis valores de FK
            for (Coluna col : tabela.getColunas()) {
                if (col.getsConstraint() != null && col.getsConstraint().equals(Config.kFK)) {
                    arrayValores = new ArrayList<>();
                    comando.registerOutParameter(1, OracleTypes.CURSOR);
                    comando.setString(2, col.getFkNomeTabela());
                    comando.setString(3, col.getFkNomeColuna());
                    comando.execute();

                    rs = (ResultSet) comando.getObject(1); // Pega o cursor

                    //Salva os valores das possiveis FKs                    
                    while (rs.next()) {
                        arrayValores.add(rs.getString(col.getFkNomeColuna()));
                    }
                    col.setArrayConstraints(arrayValores);
                }
            }
        } catch (SQLException ex) {
            jtAreaDeStatus.setText("Erro no comando: " + sql);
            Logger.getLogger(jTabelas.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    // ----------------------------------- OPERACOES ------------------------------------
    public void inserirDados(Tabela tabela, ArrayList<String> arrayValores) throws SQLException {
        ArrayList<String> arrayValoresEdits = new ArrayList<>();

        //Coloca aspas antes dos dados ou to_date
        int i = 0;
        for (String valor : arrayValores) {
            //DATE
            if (tabela.getColunas().get(i).getsTipo().equals("DATE")) {
                arrayValoresEdits.add("to_date('" + valor + "','dd/mm/yy')");
            } else {
                arrayValoresEdits.add("'" + valor + "'");
            }
            System.out.println(arrayValoresEdits.get(i));
            i++;
        }

        ArrayDescriptor descriptor = ArrayDescriptor.createDescriptor("T_ATRIBUTOS", connection);
        ARRAY colunas = new ARRAY(descriptor, connection, tabela.getColunasNomes().toArray());
        ARRAY atributos = new ARRAY(descriptor, connection, arrayValoresEdits.toArray());

        comando = connection.prepareCall(ComandoSQL.INSERT_TABLE);
        comando.setString(1, tabela.getsNome());
        comando.setArray(2, colunas);
        comando.setArray(3, atributos);
        comando.execute();

        //Adiciona linha no modelo da TABELA
        Linha linha = new Linha(arrayValores);
        tabela.linhas.add(linha);
    }

    public void alterarDados(Tabela tabela, ArrayList<String> arrayValores, int linhaSelecionada) throws SQLException {
        String pk = tabela.getColunas().get(0).getsNome();
        String valorPk = tabela.getLinhas().get(linhaSelecionada).getValores().get(0);

        ArrayList<String> arrayValoresEdits = new ArrayList<>();
        //Coloca aspas antes dos dados ou to_date
        int i = 0;
        for (String valor : arrayValores) {
            //DATE
            if (tabela.getColunas().get(i).getsTipo().equals("DATE")) {
                arrayValoresEdits.add("to_date('" + valor + "','dd/mm/yy')");
            } else {
                arrayValoresEdits.add("'" + valor + "'");
            }
            System.out.println(arrayValoresEdits.get(i));
            i++;
        }

        //Transforma para o ARRAY que SQL reconhece
        ArrayDescriptor descriptor = ArrayDescriptor.createDescriptor("T_ATRIBUTOS", connection);
        ARRAY colunas = new ARRAY(descriptor, connection, tabela.getColunasNomes().toArray());
        ARRAY atributos = new ARRAY(descriptor, connection, arrayValoresEdits.toArray());

        comando = connection.prepareCall(ComandoSQL.UPDATE_TABLE);
        comando.setString(1, tabela.getsNome());
        comando.setArray(2, colunas);
        comando.setArray(3, atributos);
        comando.setString(4, pk);
        comando.setString(5, valorPk);
        comando.execute();

        //Adiciona linha editada no modelo da TABELA            
        Linha linhaEditada = new Linha(arrayValores);
        tabela.linhas.set(linhaSelecionada, linhaEditada);
    }

    public void excluirLinha(Tabela tabela, int linhaSelecionada) throws SQLException {
        Linha linha = tabela.getLinhas().get(linhaSelecionada);
        ArrayList<String> nomesColunas = new ArrayList<>();
        ArrayList<String> valorAtributo = new ArrayList<>();

        int indexCol = 0;
        for (Coluna col : tabela.getColunas()) {
            if (col.getIsPrimaryKey()) {
                nomesColunas.add(col.getsNome());
                valorAtributo.add(linha.getValores().get(indexCol));//Pega os valor referente a COLUNA
            }
            indexCol++;
        }

        //Transforma para o ARRAY que SQL reconhece
        ArrayDescriptor descriptor = ArrayDescriptor.createDescriptor("T_ATRIBUTOS", connection);
        ARRAY colunas = new ARRAY(descriptor, connection, nomesColunas.toArray());
        ARRAY atributos = new ARRAY(descriptor, connection, valorAtributo.toArray());

        comando = connection.prepareCall(ComandoSQL.DELETE_TABLE);
        comando.setString(1, tabela.getsNome());
        comando.setArray(2, colunas);
        comando.setArray(3, atributos);
        comando.execute();

        //Remove linha do modelo da TABELA
        tabela.getLinhas().remove(linhaSelecionada);
    }

    //------------------------------------------------ RESUMO ---------------------------------------------
    public String getResumoJogo(int idJogo) throws SQLException {
        comando = connection.prepareCall(ComandoSQL.GET_RESUMOJOGO);
        comando.setInt(1, idJogo);
        comando.registerOutParameter(2, OracleTypes.VARCHAR);
        comando.execute();

        String str = comando.getString(2);
        return str;
    }

    public ArrayList<Resumo> resumoGrupos(int numeroGrupo) throws SQLException {
        try {
            ArrayList<Resumo> arrayResumo = new ArrayList<>();
            Resumo resumo;

            comando = connection.prepareCall(ComandoSQL.GET_DADOSTABELAGRUPO);
            comando.registerOutParameter(1, OracleTypes.CURSOR);
            comando.registerOutParameter(2, OracleTypes.ARRAY, "T_DADOS");
            comando.registerOutParameter(3, OracleTypes.ARRAY, "T_DADOS");
            comando.registerOutParameter(4, OracleTypes.ARRAY, "T_DADOS");
            comando.registerOutParameter(5, OracleTypes.ARRAY, "T_DADOS");
            comando.registerOutParameter(6, OracleTypes.ARRAY, "T_DADOS");
            comando.registerOutParameter(7, OracleTypes.ARRAY, "T_DADOS");
            comando.registerOutParameter(8, OracleTypes.ARRAY, "T_DADOS");
            comando.setInt(9, numeroGrupo);
            comando.execute();

            rs = (ResultSet) comando.getObject(1); // Pega o cursor

            // Pega os arrays retornados
            BigDecimal[] arVitorias = (BigDecimal[]) comando.getArray(2).getArray();
            BigDecimal[] arDerrotas = (BigDecimal[]) comando.getArray(3).getArray();
            BigDecimal[] arEmpates = (BigDecimal[]) comando.getArray(4).getArray();
            BigDecimal[] arNumJogos = (BigDecimal[]) comando.getArray(5).getArray();
            BigDecimal[] arPorcAprov = (BigDecimal[]) comando.getArray(6).getArray();
            BigDecimal[] arMediaGols = (BigDecimal[]) comando.getArray(7).getArray();
            BigDecimal[] arVarGols = (BigDecimal[]) comando.getArray(8).getArray();

            int i = 0;
            while (rs.next()) {
                resumo = new Resumo();

                //CURSOR
                resumo.setNomeNacao(rs.getString("NOMENACAO"));
                resumo.setPontos(rs.getInt("PONTOS"));
                resumo.setGolsMarcados(rs.getInt("GOLSMARCADOS"));
                resumo.setGolsSofridos(rs.getInt("GOLSSOFRIDOS"));
                resumo.setSaldo(rs.getInt("SALDO"));

                //ARRAYS
                resumo.setVitorias(arVitorias[i]);
                resumo.setDerrotas(arDerrotas[i]);
                resumo.setEmpates(arEmpates[i]);
                resumo.setNumJogos(arNumJogos[i]);
                resumo.setPorcAprov(arPorcAprov[i]);
                resumo.setMediaGols(arMediaGols[i]);
                resumo.setVarianciaGols(arVarGols[i]);

                arrayResumo.add(resumo);
                i++;
            }
            return arrayResumo;
        } catch (SQLException ex) {
            Logger.getLogger(jTabelas.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    //----------------------------------------------- NACAO BANDEIRA ---------------------------------------------    
    public void inserirNacaoBandeira(String nomeNacao, File file) throws SQLException, FileNotFoundException {
        FileInputStream input = new FileInputStream(file);

        comando = connection.prepareCall(ComandoSQL.INSERT_NACAO);
        comando.setBinaryStream(1, (InputStream) input, (int) (file.length())); //Constroi o blob
        comando.setString(2, nomeNacao);
        comando.execute();
    }

    public void alteraNacaoBandeira(String nomeNacao, File file) throws SQLException, FileNotFoundException {
        FileInputStream input = new FileInputStream(file);

        comando = connection.prepareCall(ComandoSQL.SET_NACAOBANDEIRAS);
        comando.setBinaryStream(1, (InputStream) input, (int) (file.length())); //Constroi o blob
        comando.setString(2, nomeNacao);
        comando.execute();
    }

    public ImageIcon getNacaoBandeira(String nomeNacao) throws SQLException, FileNotFoundException, IOException {
        comando = connection.prepareCall(ComandoSQL.GET_NACAOBANDEIRAS);
        comando.registerOutParameter(1, OracleTypes.BLOB);
        comando.setString(2, nomeNacao);
        comando.execute();

        Blob blob = comando.getBlob(1);

        ImageIcon newIcon = null;
        if (blob != null) {
            InputStream input = blob.getBinaryStream();
            BufferedImage img = ImageIO.read(input);
            ImageIcon icon = new ImageIcon(img);

            Image img2 = icon.getImage();
            Image newimg = img2.getScaledInstance(100, 70, java.awt.Image.SCALE_SMOOTH);
            newIcon = new ImageIcon(newimg);
        }
        return newIcon;
    }
}
