package model;

public class ResumoJogo {

    private String resumo;
    
    private int totalCartAm;
    private int totalCartVerm;
    
    private String fase;
    private String nomeFase;
    private String sel1;
    private String sel2;
    private int grupo;
    private int golSel1;
    private int golSel2;
    private String nomeJogador;
    private String estadio;
    private String data;
    
    private int numCartAmSel1;
    private int numCartAmSel2;
    private int numCartVermSel1;
    private int numCartVermSel2;
    
    private int numPatr;
    private int numJuiz;
    private int numBandeirinhas;
    private String nomePatr;
}
