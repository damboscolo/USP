package model;

import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.table.TableColumn;

public class Tabela {

    private String sNome;
    private ArrayList<Coluna> colunas;
    public  ArrayList<Linha> linhas;
  //  private ResultSet rsLinhas;

    public String getColunasMetadatas() {
        String metadata = "";
        for (Coluna c : colunas) {
            metadata = metadata + "COLUMN ID: " + c.getIdColuna() + " \t\t"
                    + "COLUMN_NAME: " + c.getsNome() + " \t\t"
                    + "DATA_TYPE: " + c.getsTipo() + " \t\t"
                    + "DATA_LENGTH: " + c.getiTamanho() + " \t\t"
                    + "NULLABLE: " + c.getNullAble() + "\n\n";
        }
        return metadata;
    }

    public ArrayList<String> getColunasNomes() {
        ArrayList<String> colunasNomes = new ArrayList<>();
        int i;
        for (i = 0; i < colunas.size(); i++) {
            colunasNomes.add(colunas.get(i).getsNome());
        }
        return colunasNomes;
    }

    public Tabela(String sNome, ArrayList<Coluna> colunas) {
        this.sNome = sNome;
        this.colunas = colunas;
    }

    public ArrayList<Coluna> getColunas() {
        return colunas;
    }

    public void setColunas(ArrayList<Coluna> colunas) {
        this.colunas = colunas;
    }

    public String getsNome() {
        return sNome;
    }

    public void setsNome(String sNome) {
        this.sNome = sNome;
    }

    public ArrayList<Linha> getLinhas() {
        return linhas;
    }

    public void setLinhas(ArrayList<Linha> linhas) {
        this.linhas = linhas;
    }



}
