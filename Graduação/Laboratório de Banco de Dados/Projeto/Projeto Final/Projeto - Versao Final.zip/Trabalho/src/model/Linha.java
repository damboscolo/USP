package model;

import java.util.ArrayList;

public class Linha {
    private ArrayList<String> valores;

    public Linha(ArrayList<String> valores) {
        this.valores = valores;
    }

    public ArrayList<String> getValores() {
        return valores;
    }

    public void setValores(ArrayList<String> valores) {
        this.valores = valores;
    }
}
