package model;

import java.util.ArrayList;

public class Coluna {
    private int idColuna;
    private String sNome;
    private String sTipo;
    private int iTamanho;
    private String nullAble;
  
    private String sConstraint; // R(FK) / C(CHECK) / U(Unique Key)
    private boolean isPrimaryKey; //True or False
    
    private String fkNomeColuna;
    private String fkNomeTabela;
    
    private ArrayList<String> arrayConstraints;

    public Coluna() {
        this.isPrimaryKey = false;
        this.sConstraint = null;
        this.arrayConstraints = null;
    }

    public int getIdColuna() {
        return idColuna;
    }

    public void setIdColuna(int idColuna) {
        this.idColuna = idColuna;
    }

    public String getsNome() {
        return sNome;
    }

    public void setsNome(String sNome) {
        this.sNome = sNome;
    }

    public Boolean getIsPrimaryKey() {
        return isPrimaryKey;
    }

    public void setIsPrimaryKey(Boolean isPrimaryKey) {
        this.isPrimaryKey = isPrimaryKey;
    }

    public String getsTipo() {
        return sTipo;
    }

    public void setsTipo(String sTipo) {
        this.sTipo = sTipo;
    }

    public int getiTamanho() {
        return iTamanho;
    }

    public void setiTamanho(int iTamanho) {
        this.iTamanho = iTamanho;
    }

    public String getNullAble() {
        return nullAble;
    }

    public void setNullAble(String nullAble) {
        this.nullAble = nullAble;
    }

    public String getFkNomeColuna() {
        return fkNomeColuna;
    }

    public void setFkNomeColuna(String fkNomeColuna) {
        this.fkNomeColuna = fkNomeColuna;
    }

    public String getFkNomeTabela() {
        return fkNomeTabela;
    }

    public void setFkNomeTabela(String fkNomeTabela) {
        this.fkNomeTabela = fkNomeTabela;
    }
    
    public String getsConstraint() {
        return sConstraint;
    }

    public void setsConstraint(String sConstraint) {
        this.sConstraint = sConstraint;
    }   

    public void setIsPrimaryKey(boolean isPrimaryKey) {
        this.isPrimaryKey = isPrimaryKey;
    }

    public ArrayList<String> getArrayConstraints() {
        return arrayConstraints;
    }

    public void setArrayConstraints(ArrayList<String> arrayConstraints) {
        this.arrayConstraints = arrayConstraints;
    }

    
}
