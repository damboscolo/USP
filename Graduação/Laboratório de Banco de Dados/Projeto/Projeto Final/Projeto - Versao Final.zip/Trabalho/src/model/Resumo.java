package model;
import java.math.BigDecimal;
import java.util.ArrayList;

public class Resumo {

    //CURSOR
    public String nomeNacao;
    public int pontos;
    public int golsMarcados;
    public int golsSofridos;
    public int saldo;
    
    //ARRAYS
    public BigDecimal numJogos;
    public BigDecimal vitorias;
    public BigDecimal derrotas;
    public BigDecimal empates;
    public BigDecimal porcAprov;
    public BigDecimal mediaGols;
    public BigDecimal varianciaGols;  
    
    public ArrayList<String> getTodosValoresString(int colocacao) {
        ArrayList<String> todosValores = new ArrayList<>();
        
        todosValores.add(String.valueOf(colocacao));        
        todosValores.add(nomeNacao);        
        todosValores.add(numJogos.toString());
        todosValores.add(String.valueOf(pontos));
        todosValores.add(String.valueOf(golsMarcados));
        todosValores.add(String.valueOf(golsSofridos));
        todosValores.add(String.valueOf(saldo));
                
        todosValores.add(vitorias.toString());       
        todosValores.add(derrotas.toString());       
        todosValores.add(empates.toString());       
        todosValores.add(mediaGols.toString()); 
        todosValores.add(varianciaGols.toString()); 
        todosValores.add(porcAprov.toString());      
              
        return todosValores;
    }
    public String getNomeNacao() {
        return nomeNacao;
    }

    public void setNomeNacao(String nomeNacao) {
        this.nomeNacao = nomeNacao;
    }

    public int getPontos() {
        return pontos;
    }

    public void setPontos(int pontos) {
        this.pontos = pontos;
    }

    public int getGolsMarcados() {
        return golsMarcados;
    }

    public void setGolsMarcados(int golsMarcados) {
        this.golsMarcados = golsMarcados;
    }

    public int getGolsSofridos() {
        return golsSofridos;
    }

    public void setGolsSofridos(int golsSofridos) {
        this.golsSofridos = golsSofridos;
    }

    public int getSaldo() {
        return saldo;
    }

    public void setSaldo(int saldo) {
        this.saldo = saldo;
    }

    public BigDecimal getNumJogos() {
        return numJogos;
    }

    public void setNumJogos(BigDecimal numJogos) {
        this.numJogos = numJogos;
    }

    public BigDecimal getVitorias() {
        return vitorias;
    }

    public void setVitorias(BigDecimal vitorias) {
        this.vitorias = vitorias;
    }

    public BigDecimal getDerrotas() {
        return derrotas;
    }

    public void setDerrotas(BigDecimal derrotas) {
        this.derrotas = derrotas;
    }

    public BigDecimal getEmpates() {
        return empates;
    }

    public void setEmpates(BigDecimal empates) {
        this.empates = empates;
    }

    public BigDecimal getPorcAprov() {
        return porcAprov;
    }

    public void setPorcAprov(BigDecimal porcAprov) {
        this.porcAprov = porcAprov;
    }

    public BigDecimal getMediaGols() {
        return mediaGols;
    }

    public void setMediaGols(BigDecimal mediaGols) {
        this.mediaGols = mediaGols;
    }

    public BigDecimal getVarianciaGols() {
        return varianciaGols;
    }

    public void setVarianciaGols(BigDecimal varianciaGols) {
        this.varianciaGols = varianciaGols;
    }

   

    
}
