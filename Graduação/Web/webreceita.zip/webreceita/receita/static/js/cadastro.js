$(function(){
   $('.datepicker').datetimepicker({
       locale: 'pt-br',
       format: 'DD/MM/YYYY'
   });
});