define([
	"./arr"
], function( arr ) {
	return arr.indexOf;
});
