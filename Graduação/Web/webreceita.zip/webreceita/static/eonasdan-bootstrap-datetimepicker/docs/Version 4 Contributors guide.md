<meta http-equiv="refresh" content="1; url=/Changelog/"/>
<meta http-equiv="refresh" content="0; url=/ContributorsGuide/"/>
<link rel="canonical" href="/ContributorsGuide/">

 <p>The page has moved to: 
   <a href="/ContributorsGuide/">this page</a></p>